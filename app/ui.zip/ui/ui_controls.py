# app/ui/ui_controls.py
import streamlit as st
from state import (
    get_current_speaker,
    context_summary_for_prompt,
    get_question_constraints,
    next_speaker,
    skip_speaker,
    end_session,
)
from timer import start_timer, stop_timer
from audio_io import listen_start, listen_stop
from tts import generate_tts_mp3, tts_preprocess
from question_gen import (
    generate_initial_question,
    generate_followup_question,
    simplify_question as simplify_text,
    approve_question,
    QuestionConstraints,
)


def _render_prompt(template_path: str, **vars) -> str:
    text = Path(template_path).read_text(encoding="utf-8")
    for k, v in vars.items():
        text = text.replace(f"{{{{{k}}}}}", v or "")
    return text


def _constraints_with_theme() -> QuestionConstraints:
    base = get_question_constraints()
    theme = (st.session_state.get("theme") or "").strip()

    if st.session_state.get("prompt_mode") == "Topic Pack":
        pack = (st.session_state.get("topic_pack") or "").strip()
        diff = (st.session_state.get("topic_difficulty") or "").strip()
        if pack:
            theme = f"{pack} ({diff})" if diff else pack

    return QuestionConstraints(
        creativity=base.creativity,
        max_seconds=base.max_seconds,
        style=base.style,
        avoid_topics=base.avoid_topics,
        require_word=base.require_word,
        theme=theme or None,
    )


def _ensure_summaries_len(target_len: int) -> None:
    if target_len <= 0:
        return
    summaries = st.session_state.get("speaker_summaries")
    if not isinstance(summaries, list):
        summaries = []
    while len(summaries) < target_len:
        summaries.append("")
    st.session_state["speaker_summaries"] = summaries


def _store_summary_for_current_speaker(summary_text: str) -> None:
    idx = int(st.session_state.get("speaker_index", 0))
    speakers = st.session_state.get("speakers", [])
    target_len = max(len(speakers), idx + 1)
    _ensure_summaries_len(target_len)
    st.session_state["speaker_summaries"][idx] = summary_text.strip()
    st.session_state["last_summary"] = summary_text.strip()


def _get_prev_summary(idx: int) -> str:
    summaries = st.session_state.get("speaker_summaries")
    if isinstance(summaries, list) and idx - 1 >= 0 and idx - 1 < len(summaries):
        s = summaries[idx - 1]
        if isinstance(s, str) and s.strip():
            return s.strip()
    v = st.session_state.get("last_summary", "")
    if isinstance(v, str) and v.strip():
        return v.strip()
    t = st.session_state.get("current_transcript", "")
    return t.strip() if isinstance(t, str) else ""


def render_speaker_queue():
    """Render the speaker queue showing current + next speakers."""
    speakers = st.session_state.get("speakers", [])
    idx = st.session_state.get("speaker_index", 0)

    if not speakers:
        st.caption("No speakers loaded")
        return

    st.markdown("**Speaker Queue**")
    for i, name in enumerate(speakers):
        if i < idx:
            css_class = "done"
            prefix = "~~"
            suffix = "~~"
        elif i == idx:
            css_class = "current"
            prefix = "**"
            suffix = "** (current)"
        elif i <= idx + 3:
            css_class = "upcoming"
            prefix = ""
            suffix = ""
        else:
            continue

        st.markdown(
            f'<div class="speaker-queue-item {css_class}">{i+1}. {prefix}{name}{suffix}</div>',
            unsafe_allow_html=True,
        )


def render_operator_controls():
    """Render the right-column operator panel."""
    session_active = st.session_state.get("session_started", False)
    state = st.session_state.get("system_state", "idle")

    st.markdown("### Operator Controls")

    # Speaker queue
    render_speaker_queue()
    st.divider()

    # --- Question Generation ---
    st.markdown("**Question Controls**")
    q1, q2 = st.columns(2)
    with q1:
        if st.button("Ask Question", disabled=not session_active, use_container_width=True, key="btn_ask"):
            st.session_state["system_state"] = "thinking"
            st.session_state["system_state_note"] = "Generating question"

            constraints = _constraints_with_theme()
            speaker = get_current_speaker() or "Speaker"
            ctx = context_summary_for_prompt()
            idx = int(st.session_state.get("speaker_index", 0))

            if idx == 0 or not st.session_state.get("last_summary", "").strip():
                st.session_state["proposed_question"] = generate_initial_question(
                    speaker=speaker,
                    context=ctx,
                    constraints=constraints,
                )
            else:
                speakers = st.session_state.get("speakers", [])
                prev_speaker = speakers[idx - 1] if (idx > 0 and idx - 1 < len(speakers)) else "the previous speaker"
                prev_summary = _get_prev_summary(idx)

                st.session_state["proposed_question"] = generate_followup_question(
                    next_speaker=speaker,
                    context=ctx,
                    prev_speaker=prev_speaker,
                    prev_transcript="",
                    prev_summary=prev_summary,
                    prev_question=st.session_state.get("approved_question", ""),
                    template_index=max(0, idx - 1),
                    constraints=constraints,
                )

            st.session_state["system_state"] = "ready"
            st.session_state["system_state_note"] = "Question proposed"
            st.rerun()

    with q2:
        if st.button("Follow-Up", disabled=not session_active, use_container_width=True, key="btn_followup"):
            st.session_state["system_state"] = "thinking"
            st.session_state["system_state_note"] = "Generating follow-up"

            constraints = _constraints_with_theme()
            ctx = context_summary_for_prompt()
            idx = int(st.session_state.get("speaker_index", 0))
            speakers = st.session_state.get("speakers", [])
            prev_speaker = speakers[idx - 1] if (idx > 0 and idx - 1 < len(speakers)) else "the previous speaker"
            next_speaker_name = get_current_speaker() or "Speaker"
            prev_summary = _get_prev_summary(idx)

            st.session_state["proposed_question"] = generate_followup_question(
                next_speaker=next_speaker_name,
                context=ctx,
                prev_speaker=prev_speaker,
                prev_transcript="",
                prev_summary=prev_summary,
                prev_question=st.session_state.get("approved_question", ""),
                template_index=max(0, idx - 1),
                constraints=constraints,
            )

            st.session_state["system_state"] = "ready"
            st.session_state["system_state_note"] = "Question proposed"
            st.rerun()

    # Show proposed question
    proposed = (st.session_state.get("proposed_question") or "").strip()
    if proposed:
        st.info(f"**Proposed:** {proposed}")
        ap1, ap2 = st.columns(2)
        with ap1:
            if st.button("Approve & Speak", use_container_width=True, key="btn_approve_speak"):
                st.session_state["approved_question"] = approve_question(proposed)
                st.session_state["proposed_question"] = ""
                st.session_state["system_state"] = "speaking"
                st.session_state["system_state_note"] = "Speaking question"

                try:
                    text = st.session_state["approved_question"]
                    wod = (st.session_state.get("word_of_day") or "").strip() if st.session_state.get("tts_emphasize_wod") else ""
                    shaped = tts_preprocess(
                        text,
                        pace=st.session_state.get("tts_pace", "tight"),
                        emphasize=wod or None,
                    )
                    st.session_state["tts_audio_mp3"] = generate_tts_mp3(
                        shaped,
                        model=st.session_state.get("tts_model", "tts-1"),
                        voice=st.session_state.get("tts_voice", "alloy"),
                    )
                    st.session_state["tts_last_text"] = shaped
                    st.session_state["tts_last_error"] = ""
                    st.session_state["system_state"] = "ready"
                    st.session_state["system_state_note"] = "Audio ready"
                except Exception as e:
                    st.session_state["tts_last_error"] = str(e)
                    st.session_state["system_state"] = "ready"
                    st.session_state["system_state_note"] = "TTS failed"
                st.rerun()

        with ap2:
            if st.button("Approve Only", use_container_width=True, key="btn_approve_only"):
                st.session_state["approved_question"] = approve_question(proposed)
                st.session_state["proposed_question"] = ""
                st.session_state["system_state"] = "ready"
                st.session_state["system_state_note"] = "Question approved"
                st.rerun()

    st.divider()

    # --- Listen / Stop ---
    st.markdown("**Audio Controls**")
    l1, l2 = st.columns(2)
    with l1:
        if st.button(
            "Listen",
            disabled=(not session_active or state == "listening"),
            use_container_width=True,
            key="btn_listen",
        ):
            listen_start()
            start_timer()
            st.session_state["system_state"] = "listening"
            st.session_state["system_state_note"] = "Recording"
            st.rerun()

    with l2:
        if st.button(
            "Stop Listening",
            disabled=(state != "listening"),
            use_container_width=True,
            key="btn_stop_listen",
        ):
            listen_stop()
            stop_timer()
            st.session_state["awaiting_audio_stop"] = True
            st.session_state["system_state"] = "thinking"
            st.session_state["system_state_note"] = "Finalizing audio"
            st.rerun()

    st.divider()

    # --- Speaker Navigation ---
    st.markdown("**Speaker Navigation**")
    n1, n2, n3 = st.columns(3)
    with n1:
        if st.button("Repeat", disabled=not bool(st.session_state.get("tts_audio_mp3")), use_container_width=True, key="btn_repeat"):
            st.session_state["system_state"] = "ready"
            st.session_state["system_state_note"] = "Repeating audio"
            st.rerun()

    with n2:
        if st.button("Skip Speaker", disabled=not session_active, use_container_width=True, key="btn_skip"):
            skip_speaker(stop_timer)
            st.session_state["system_state"] = "ready"
            st.session_state["system_state_note"] = "Skipped speaker"
            st.rerun()

    with n3:
        if st.button("Next Speaker", disabled=not session_active, use_container_width=True, key="btn_next"):
            next_speaker(stop_timer)
            st.session_state["system_state"] = "ready"
            st.session_state["system_state_note"] = "Next speaker"
            st.rerun()

    # Emergency fallback
    if st.button("Emergency: Generic Question", disabled=not session_active, use_container_width=True, key="btn_emergency"):
        qs = st.session_state.get("fallback_questions", [])
        if qs:
            idx = int(st.session_state.get("speaker_index", 0)) % len(qs)
            st.session_state["approved_question"] = qs[idx]
            st.session_state["proposed_question"] = ""
            st.session_state["tts_audio_mp3"] = None
            st.session_state["system_state"] = "ready"
            st.session_state["system_state_note"] = "Using fallback question"
        else:
            st.session_state["system_state_note"] = "No fallback questions loaded"
        st.rerun()

    # End Session button
    st.divider()
    if st.button("End Session", disabled=not session_active, use_container_width=True, key="btn_end_session", type="secondary"):
        end_session(stop_timer)
        st.switch_page("pages/results.py")

    st.divider()

    # --- Collapsible sections ---
    with st.expander("Live Transcript", expanded=False):
        transcript = (st.session_state.get("current_transcript") or "").strip()
        if transcript:
            st.text_area("Transcript", value=transcript, height=150, disabled=True, key="tx_display")
        else:
            st.caption("No transcript yet")

    with st.expander("Summary", expanded=False):
        summary = (st.session_state.get("last_summary") or "").strip()
        if summary:
            st.info(summary)
        else:
            st.caption("No summary yet")

    with st.expander("Evaluator Notes", expanded=False):
        notes = (st.session_state.get("evaluator_notes") or "").strip()
        if notes:
            st.info(notes)
        else:
            st.caption("No evaluator notes yet")

        hint = (st.session_state.get("coach_hint") or "").strip()
        if hint:
            st.caption(f"Coach hint: {hint}")

    # Show errors if any
    if st.session_state.get("tts_last_error"):
        st.error(f"TTS: {st.session_state['tts_last_error']}")
    if st.session_state.get("stt_last_error"):
        st.error(f"STT: {st.session_state['stt_last_error']}")
    if st.session_state.get("summarizer_last_error"):
        st.warning(f"Summarizer: {st.session_state['summarizer_last_error']}")
    if st.session_state.get("evaluator_last_error"):
        st.warning(f"Evaluator: {st.session_state['evaluator_last_error']}")
