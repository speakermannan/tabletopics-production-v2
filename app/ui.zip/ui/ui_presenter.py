# app/ui/ui_presenter.py
import streamlit as st
from timer import elapsed_sec, stoplight_state


def render_presenter_view():
    """Render the left-column presenter view (screen-share friendly)."""
    theme = (st.session_state.get("theme") or "").strip()
    wod = (st.session_state.get("word_of_day") or "").strip()

    if st.session_state.get("prompt_mode") == "Topic Pack":
        pack = (st.session_state.get("topic_pack") or "").strip()
        diff = (st.session_state.get("topic_difficulty") or "").strip()
        theme = f"{pack} ({diff})" if pack else theme
        wod = ""

    speakers = st.session_state.get("speakers", [])
    idx = st.session_state.get("speaker_index", 0)
    current_speaker = speakers[idx] if speakers and 0 <= idx < len(speakers) else "---"

    question = (st.session_state.get("approved_question") or "").strip()
    state = st.session_state.get("system_state", "idle")

    # Timer
    el = elapsed_sec()
    tgt = int(st.session_state.get("timer_target_sec", 90))
    label, color = stoplight_state(el, tgt)
    running = st.session_state.get("timer_running", False)
    timer_text = f"{el}s / {tgt}s" if running else "Timer stopped"

    # State pill colours (muted, matching reference)
    state_colors = {
        "idle": "#AEB6BF",
        "listening": "#27AE60",
        "thinking": "#E67E22",
        "ready": "#2E86C1",
        "speaking": "#8E44AD",
    }
    state_bg = {
        "idle": "rgba(174,182,191,0.18)",
        "listening": "rgba(39,174,96,0.18)",
        "thinking": "rgba(230,126,34,0.18)",
        "ready": "rgba(46,134,193,0.18)",
        "speaking": "rgba(142,68,173,0.18)",
    }

    st.markdown(f"""
    <div class="presenter-panel">
        <div class="theme-strip">
            <span><strong>Theme:</strong> {theme or '---'}</span>
            <span><strong>Word of the Day:</strong> {wod or '---'}</span>
        </div>

        <div class="speaker-name">Now Speaking: {current_speaker}</div>

        <div class="question-display">
            {question or '<span style="opacity:0.35; font-size:1rem;">No question yet &mdash; generate one from the operator panel</span>'}
        </div>

        {"<div class='wod-hint'>Please use: <strong>" + wod + "</strong></div>" if wod else ""}

        <div style="display:flex; align-items:center; gap:1.2rem; margin-top:0.8rem;">
            <span style="
                display:inline-block;
                padding:0.3rem 1rem;
                border-radius:16px;
                font-weight:600;
                font-size:0.8rem;
                background:{state_bg.get(state, state_bg['idle'])};
                color:{state_colors.get(state, state_colors['idle'])};
                letter-spacing:0.3px;
            ">{state.upper()}</span>

            <div class="timer-display">
                <div class="timer-circle" style="background:{color};"></div>
                <div>
                    <div class="timer-text">{timer_text}</div>
                    <div class="timer-sub">Timer: {label}</div>
                </div>
            </div>
        </div>
    </div>
    """, unsafe_allow_html=True)

    # Audio player (if TTS generated)
    if st.session_state.get("tts_audio_mp3"):
        st.audio(st.session_state["tts_audio_mp3"], format="audio/mp3")
