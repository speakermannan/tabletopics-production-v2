# app/ui/ui_shell.py
import streamlit as st


def inject_custom_css():
    st.markdown("""
    <style>
        /* =============================================
           GLOBAL
           Flat, corporate SaaS feel.
           Page bg: #F5F7FA  |  Cards: #FFF  |  Navy: #1B3A5C
           ============================================= */

        /* Force light mode everywhere */
        .stApp, .stApp > header, .stApp > div,
        [data-testid="stAppViewContainer"],
        [data-testid="stAppViewBlockContainer"],
        .main, .main .block-container,
        [data-testid="stMainBlockContainer"] {
            background-color: #F5F7FA !important;
            color: #2D3436 !important;
        }

        .block-container {
            padding-top: 1rem;
            max-width: 1400px;
        }

        /* ---- App header (flat white bar, not gradient) ---- */
        .app-header {
            background: #FFFFFF;
            border: 1px solid #DEE2E6;
            border-radius: 10px;
            padding: 0.75rem 1.25rem;
            margin-bottom: 1.25rem;
            display: flex;
            align-items: center;
            gap: 0.9rem;
        }
        .app-header h1 {
            margin: 0;
            font-size: 1.35rem;
            font-weight: 700;
            color: #1B3A5C;
        }
        .app-header .subtitle {
            font-size: 0.8rem;
            color: #636E72;
            margin-top: 2px;
        }
        .app-header .logo-circle {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: #1B3A5C;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.85rem;
            font-weight: 700;
            color: #FFFFFF;
            flex-shrink: 0;
            letter-spacing: 0.5px;
        }

        /* ---- Cards (thin border, flat, no heavy shadow) ---- */
        .ui-card {
            background: #FFFFFF;
            border: 1px solid #DEE2E6;
            border-radius: 8px;
            padding: 1.1rem 1.3rem;
            margin-bottom: 1rem;
        }
        .ui-card h3 {
            margin-top: 0;
            margin-bottom: 0.6rem;
            color: #1B3A5C;
            font-size: 1rem;
            font-weight: 600;
        }

        /* ---- State pills ---- */
        .state-pill {
            display: inline-block;
            padding: 0.25rem 0.85rem;
            border-radius: 16px;
            font-weight: 600;
            font-size: 0.78rem;
            letter-spacing: 0.3px;
        }
        .state-pill.idle       { background: #EAECEE; color: #636E72; }
        .state-pill.listening  { background: #D5F5E3; color: #1E8449; }
        .state-pill.thinking   { background: #FDEBD0; color: #CA6F1E; }
        .state-pill.ready      { background: #D6EAF8; color: #1B4F72; }
        .state-pill.speaking   { background: #E8DAEF; color: #6C3483; }

        /* ---- Presenter panel (dark navy, matches reference) ---- */
        .presenter-panel {
            background: #162447;
            color: #F0F0F0;
            border-radius: 12px;
            padding: 1.8rem;
            min-height: 480px;
        }
        .presenter-panel .theme-strip {
            background: rgba(255,255,255,0.08);
            padding: 0.45rem 0.9rem;
            border-radius: 6px;
            font-size: 0.82rem;
            margin-bottom: 1.3rem;
            display: flex;
            gap: 1.8rem;
            color: #CCD1D9;
        }
        .presenter-panel .theme-strip strong {
            color: #FFFFFF;
        }
        .presenter-panel .speaker-name {
            font-size: 1.5rem;
            font-weight: 700;
            color: #7EC8E3;
            margin-bottom: 0.9rem;
        }
        .presenter-panel .question-display {
            font-size: 1.5rem;
            font-weight: 500;
            line-height: 1.45;
            padding: 1.3rem;
            background: rgba(255,255,255,0.06);
            border-radius: 10px;
            border-left: 3px solid #5DADE2;
            margin-bottom: 1.2rem;
            min-height: 100px;
            color: #FFFFFF;
        }
        .presenter-panel .wod-hint {
            font-size: 1rem;
            color: #F5CBA7;
            font-style: italic;
            margin-bottom: 0.8rem;
        }

        /* ---- Timer (inside presenter) ---- */
        .timer-display {
            display: flex;
            align-items: center;
            gap: 0.8rem;
            padding: 0.6rem 1rem;
            border-radius: 8px;
            background: rgba(255,255,255,0.06);
        }
        .timer-circle {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            border: 2px solid rgba(255,255,255,0.2);
        }
        .timer-text {
            font-size: 1.2rem;
            font-weight: 700;
            color: #FFFFFF;
        }
        .timer-sub {
            font-size: 0.78rem;
            color: #AEB6BF;
        }

        /* ---- Speaker queue items ---- */
        .speaker-queue-item {
            padding: 0.4rem 0.7rem;
            border-radius: 6px;
            margin-bottom: 0.25rem;
            font-size: 0.85rem;
        }
        .speaker-queue-item.current {
            background: #1B3A5C;
            color: #FFFFFF;
            font-weight: 600;
        }
        .speaker-queue-item.upcoming {
            background: #EBF5FB;
            color: #1B4F72;
        }
        .speaker-queue-item.done {
            background: #F4F6F7;
            color: #ABB2B9;
            text-decoration: line-through;
        }

        /* ---- Result cards ---- */
        .result-card {
            background: #FFFFFF;
            border: 1px solid #DEE2E6;
            border-radius: 8px;
            padding: 1rem 1.3rem;
            margin-bottom: 0.8rem;
        }
        .result-card .speaker-name {
            font-size: 1rem;
            font-weight: 600;
            color: #1B3A5C;
        }
        .result-card .question-text {
            font-style: italic;
            color: #636E72;
            margin: 0.35rem 0;
            font-size: 0.9rem;
        }

        /* ---- Home hero ---- */
        .home-hero {
            text-align: center;
            padding: 2.5rem 2rem 1.5rem;
        }
        .home-hero h1 {
            font-size: 2rem;
            color: #1B3A5C;
            font-weight: 700;
            margin-bottom: 0.3rem;
        }
        .home-hero .tagline {
            font-size: 0.95rem;
            color: #636E72;
            margin-bottom: 1.8rem;
        }

        /* ---- Feature cards (home bottom row) ---- */
        .feature-card {
            background: #FFFFFF;
            border: 1px solid #DEE2E6;
            border-radius: 8px;
            padding: 1.1rem 1rem;
            text-align: center;
            min-height: 145px;
        }
        .feature-card .icon-circle {
            width: 44px;
            height: 44px;
            border-radius: 50%;
            background: #1B3A5C;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 0.6rem;
            color: #FFFFFF;
            font-size: 1.15rem;
        }
        .feature-card h4 {
            margin: 0 0 0.3rem 0;
            font-size: 0.88rem;
            font-weight: 600;
            color: #1B3A5C;
        }
        .feature-card p {
            margin: 0;
            font-size: 0.76rem;
            color: #636E72;
            line-height: 1.35;
        }

        /* ---- Override Streamlit defaults ---- */
        header[data-testid="stHeader"] { background: transparent; }

        /* Streamlit button colour overrides (navy primary) */
        .stButton > button[kind="primary"],
        .stButton > button[data-testid="stBaseButton-primary"] {
            background-color: #1B3A5C;
            border-color: #1B3A5C;
            color: #FFFFFF;
        }
        .stButton > button[kind="primary"]:hover,
        .stButton > button[data-testid="stBaseButton-primary"]:hover {
            background-color: #154360;
            border-color: #154360;
        }

        /* Secondary / default buttons: outlined navy */
        .stButton > button[kind="secondary"],
        .stButton > button[data-testid="stBaseButton-secondary"] {
            background-color: #FFFFFF;
            border: 1px solid #1B3A5C;
            color: #1B3A5C;
        }
        .stButton > button[kind="secondary"]:hover,
        .stButton > button[data-testid="stBaseButton-secondary"]:hover {
            background-color: #EBF5FB;
        }

        /* Sidebar tweaks */
        section[data-testid="stSidebar"] {
            background: #FFFFFF;
            border-right: 1px solid #DEE2E6;
        }
    </style>
    """, unsafe_allow_html=True)


def render_header(subtitle: str = ""):
    st.markdown(f"""
    <div class="app-header">
        <div class="logo-circle">TT</div>
        <div>
            <h1>AI Table Topics Co-Host</h1>
            <div class="subtitle">{subtitle or "Theme + Word of the Day &rarr; Contextual Questions &rarr; Live Summaries"}</div>
        </div>
    </div>
    """, unsafe_allow_html=True)


def render_state_pill(state: str):
    return f'<span class="state-pill {state.lower()}">{state.upper()}</span>'


def render_sidebar():
    with st.sidebar:
        st.markdown("### Session Status")

        state = st.session_state.get("system_state", "idle")
        note = st.session_state.get("system_state_note", "")
        st.markdown(render_state_pill(state), unsafe_allow_html=True)
        if note:
            st.caption(note)

        st.divider()

        if st.session_state.get("session_started"):
            speakers = st.session_state.get("speakers", [])
            idx = st.session_state.get("speaker_index", 0)
            st.markdown(f"**Speakers:** {len(speakers)}")
            st.markdown(f"**Current:** {idx + 1} of {len(speakers)}")
            theme = (st.session_state.get("theme") or "").strip()
            if theme:
                st.markdown(f"**Theme:** {theme}")
            wod = (st.session_state.get("word_of_day") or "").strip()
            if wod:
                st.markdown(f"**Word:** {wod}")

        st.divider()

        if st.button("Reset Session", key="sidebar_reset", use_container_width=True):
            from state import reset_session
            reset_session()
            st.rerun()
